import { createRootRoute, Outlet, Link } from '@tanstack/react-router'

import { useLocation } from "@tanstack/react-router";
import { useEffect } from "react";


export const Route = createRootRoute({
    component: RootLayout,
    notFoundComponent: NotFoundPage

})
function RootLayout() {
    return(
    <>
        <Outlet />
    </>
    )
}

function NotFoundPage(){

    const location = useLocation();
    useEffect(() => {
        console.error("404 Error: User attempted to access non-existent route:", location.pathname);
    }, [location.pathname]);

    return(
    <div className="flex min-h-screen items-center justify-center bg-muted">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-bold">404</h1>
        <p className="mb-4 text-xl text-muted-foreground">Oops! Page not found</p>
        <Link to="/" className='text-primary underline hover:text-primary/90'>
            Return to Home
        </Link>
      </div>
    </div>
    )
}